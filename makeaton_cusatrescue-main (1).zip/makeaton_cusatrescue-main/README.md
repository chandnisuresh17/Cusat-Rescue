# makeaton_cusatrescue
A web app useful for students, faculties, workers or even by-passers in the campus of Cochin University of Science and Technology. The application displays a map of the campus, such that when a user selects any department/block/building on the map, they'll be redirected to the next page that displays every activity that takes place within that block. Online registrations can hence be done through this and this makes it much easier for students because only specific details required for that activity has to be filled, all the remaining college details of the student will be retrieved from account details of the user. Faculties working in that will also find it easy to collect data and directly enter into database. Users can also view the opening/closing time and food availability of cafes and restaurants within the campus. Further scope of the web-app is to indicate dangerous areas at times of strikes in the campus.
.
.
.
This web app was made as a part of Hackathon project along with 4 other team-mates.
